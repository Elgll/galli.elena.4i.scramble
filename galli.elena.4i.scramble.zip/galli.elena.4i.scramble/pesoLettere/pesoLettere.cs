using System;
using System.Collections.Generic;
public static class PesoLettere
{

    public static int Pesa(string input)
    {
        int punteggio = 0;
        string controllo1 = "aeioulnrstAEIOULNRST";
        string controllo2 = "dgDG";
        string controllo3 = "bcmpBCMP";
        string controllo4 = "fhvwyFHVWY";
        string controllo5 = "kK";
        string controllo8 = "jxJX";
        string controllo10 = "qzQZ";
        
        foreach(char letter in  controllo1) if (input.Contains(letter)) punteggio+=1;
        foreach(char letter in  controllo2) if (input.Contains(letter)) punteggio+=2;
        foreach(char letter in  controllo3) if (input.Contains(letter)) punteggio+=3;
        foreach(char letter in  controllo4) if (input.Contains(letter)) punteggio+=4;
        foreach(char letter in  controllo5) if (input.Contains(letter)) punteggio+=5;
        foreach(char letter in  controllo8) if (input.Contains(letter)) punteggio+=8;
        foreach(char letter in  controllo10) if (input.Contains(letter)) punteggio+=10;
        return punteggio;
    }
}